# Spark_HC_SR04
A Spark Photon/Core library for the HC-SR04 Ultrasonic Rangefinder
