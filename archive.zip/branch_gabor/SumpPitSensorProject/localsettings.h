// This file intended to contain local configuration.
// Changes to this file should not be committed to the repo.

// Example:
// uncomment one of the lines below, keep the same lines commented in the
// application.ino file.
//
// #define PLATFORM PLATFORM_PHOTON
// #define PLATFORM PLATFORM_ELECTRON
