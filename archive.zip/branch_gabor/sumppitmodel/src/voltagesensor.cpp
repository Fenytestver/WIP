#include "voltagesensor.h"

VoltageSensor::VoltageSensor()
{
  //ctor
}

VoltageSensor::~VoltageSensor()
{
  //dtor
}
float VoltageSensor::getVoltage()
{
  return 0;
}

void VoltageSensor::setup()
{
}
