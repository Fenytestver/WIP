#include "systemtime.h"

SystemTime::SystemTime()
{
  //ctor
}

SystemTime::~SystemTime()
{
  //dtor
}

long SystemTime::nowMillis() {
  return 0L;
}
