#include "siren.h"

Siren::Siren()
{
  //ctor
}

Siren::~Siren()
{
  //dtor
}

void Siren::setup()
{

}
void Siren::update() {
  
}
void Siren::on()
{

}

void Siren::off()
{

}
