#include "onbuttonpresslistener.h"

OnButtonPressListener::OnButtonPressListener()
{
  //ctor
}

OnButtonPressListener::~OnButtonPressListener()
{
  //dtor
}
void OnButtonPressListener::onPress()
{

}
