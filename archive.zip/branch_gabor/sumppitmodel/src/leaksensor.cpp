#include "leaksensor.h"

LeakSensor::LeakSensor()
{
  //ctor
}

LeakSensor::~LeakSensor()
{
  //dtor
}
bool LeakSensor::isLeaking()
{
  return false;
}
