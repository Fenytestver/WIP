#include "display.h"

Display::Display()
{
  //ctor
}

Display::~Display()
{
  //dtor
}
void Display::displayMessage(char*)
{

}

void Display::clear()
{

}

void Display::setup() {

}
void Display::show(State state)
{

}
