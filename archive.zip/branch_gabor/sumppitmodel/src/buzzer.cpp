#include "buzzer.h"

Buzzer::Buzzer()
{
  //ctor
}

Buzzer::~Buzzer()
{
  //dtor
}
void Buzzer::beep()
{

}
