#include "rpmsensor.h"

RpmSensor::RpmSensor()
{
  //ctor
}

RpmSensor::~RpmSensor()
{
  //dtor
}

void RpmSensor::setup() {
  
}

int RpmSensor::getRpm()
{
  return 0;
}
