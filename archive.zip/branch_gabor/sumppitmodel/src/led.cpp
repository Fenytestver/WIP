#include "led.h"
Led::Led()
{

}

Led::~Led()
{

}

void Led::setup() {
  
}

void Led::setState(bool on)
{

}
