#include "shutoffvalve.h"

ShutoffValve::ShutoffValve()
{
  //ctor
}

ShutoffValve::~ShutoffValve()
{
  //dtor
}
void ShutoffValve::activate()
{

}

void ShutoffValve::deactivate()
{

}
bool ShutoffValve::isActive()
{
  return false;
}
