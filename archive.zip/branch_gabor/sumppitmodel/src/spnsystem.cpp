#include "spnsystem.h"

SPNSystem::SPNSystem()
{
  //ctor
}

SPNSystem::~SPNSystem()
{
  //dtor
}
