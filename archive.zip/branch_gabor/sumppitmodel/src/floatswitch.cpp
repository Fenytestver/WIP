#include "floatswitch.h"

FloatSwitch::FloatSwitch() {

}

bool FloatSwitch::isTriggered() {
  return false;
}

void FloatSwitch::setup() {
  
}
