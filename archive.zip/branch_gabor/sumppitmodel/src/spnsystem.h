#ifndef SPNSYSTEM_H
#define SPNSYSTEM_H


class SPNSystem
{
  public:
    /** Default constructor */
    SPNSystem();
    /** Default destructor */
    virtual ~SPNSystem();

  protected:

  private:
};

#endif // SPNSYSTEM_H
