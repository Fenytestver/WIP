#include <iostream>
#ifndef TEST_NORMALOPERATION_H
#define TEST_NORMALOPERATION_H
#include "functionaltestbase.h"

class test_normaloperation : public FunctionalTestBase
{
  public:
    test_normaloperation();
    virtual void test();
  protected:

  private:
};

#endif // TEST_NORMALOPERATION_H
