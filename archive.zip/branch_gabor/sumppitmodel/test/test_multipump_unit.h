#ifndef TEST_MULTIPUMP_UNIT_H
#define TEST_MULTIPUMP_UNIT_H
#include "testbase.h"
#include "stubs.cpp"

class test_multipump_unit : public TestBase
{
  public:
    test_multipump_unit();
    virtual ~test_multipump_unit();
    virtual void test();
  protected:

  private:

};

#endif // TEST_MULTIPUMP_UNIT_H
