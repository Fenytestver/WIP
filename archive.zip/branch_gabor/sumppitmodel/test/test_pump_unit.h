#ifndef TEST_PUMP_UNIT_H
#define TEST_PUMP_UNIT_H
#include "functionaltestbase.h"

class test_pump_unit : public FunctionalTestBase
{
  public:
    test_pump_unit();
    virtual ~test_pump_unit();
    void test();
  protected:

  private:
};

#endif // TEST_PUMP_UNIT_H
