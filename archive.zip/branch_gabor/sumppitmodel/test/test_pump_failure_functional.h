#ifndef TEST_PUMP_FAILURE_FUNCTIONAL_H
#define TEST_PUMP_FAILURE_FUNCTIONAL_H

#include "functionaltestbase.h"

class test_pump_failure_functional : public FunctionalTestBase
{
  public:
    test_pump_failure_functional();
    virtual ~test_pump_failure_functional();
    virtual void test();
  protected:

  private:
};

#endif // TEST_PUMP_FAILURE_FUNCTIONAL_H
