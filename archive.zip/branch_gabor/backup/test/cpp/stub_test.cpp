#include "gtest/gtest.h"


TEST(StubsTests, test_constructor) {
    
}