# Sump Pit Sensor & Remote monitoring

## Overview
to stop tracking local onfiguration files, run this git command in SumpPitSensorProject/src/:
git update-index --skip-worktree localsettings.h


## Project structure

SumpPitSensorProject	// project root
	lib					// libraries
		sumppitmodel	// main business logic implementation
	src					// main, runnable files
	test				// test code
## Links
http://particle.io - Particle.io

http://bitbucket.com - Version control (git)

https://www.sourcetreeapp.com/ - Win/Mac client for Git

